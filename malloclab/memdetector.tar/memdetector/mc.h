#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <stddef.h>


// typedef struct __item {
//     void *ptr;
//     size_t size;
//     int cnt;
//     char fname[32];
//     unsigned long long ofs;
//     struct __item *next;
// } item;
